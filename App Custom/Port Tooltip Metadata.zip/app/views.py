"""Licensed Materials - Property of IBM
5725I71-CC011829
(C) Copyright IBM Corp. 2017, 2018. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with IBM Corp."""
__author__ = 'staze0'



from app import app
from flask import render_template
from flask import request
from qpylib import qpylib

import json

@app.route('/port_metadata_provider', methods=['GET'])
def getPortMetadata():
    
    ref_map_of_sets_name = 'Port List'
    
    try:
        headers = {'SEC':'97c2a032-41a6-4e7c-b0b4-4f4f3ecb70e3', 'Accept' : 'application/json'}
        response = qpylib.REST( 'get', '/api/reference_data/map_of_sets/{0}'.format(ref_map_of_sets_name), headers = headers )
    except Exception as e:
        qpylib.log( "Error "  + str(e) , 'error')
        raise
    
    response_json = json.loads(response.text)
    app_id = qpylib.get_app_id()
    port_number = request.args.get('context')
    
    try:
        information_port = response_json["data"][port_number]
    except KeyError:
        information_port_parsed = "No informations found in refs. You can add information about this port in {0} ref map of sets.".format(ref_map_of_sets_name)
    else:
        information_port_parsed = ""
        for info in information_port:
            information_port_parsed += "{0} ".format(info["value"])
        information_port_parsed += ""
        
    information_appendix = "https://www.speedguide.net/port.php?port={0}".format(port_number)
    
    qpylib.log("### DEBUG ### : {0}".format(information_port_parsed))
    qpylib.log("### DEBUG ### : {0}".format(information_appendix))

    metadata_dict = {
        'key': 'PortMetadataProvider',
        'label': '',
        'value': 'Metadata value',
        'html': render_template('metadata_port.html', port_information=information_port_parsed, appendix=information_appendix, app_id=app_id)
    }

    return json.dumps(metadata_dict)
